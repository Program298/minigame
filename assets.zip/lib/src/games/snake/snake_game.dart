import 'dart:async';
import 'dart:math';
import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:minigame/src/games/base_game.dart';
import 'package:minigame/src/games/snake/snake_piece.dart';
import 'package:minigame/src/games/snake/food.dart';

enum Direction { up, down, left, right, none }

class SnakeGame extends BaseGame with HasCollisionDetection, KeyboardEvents {
  static const gridSize = 20.0;
  static const initialSnakeLength = 3;
  
  late List<SnakePiece> snake;
  late Food food;
  late Direction direction;
  late Direction nextDirection;
  late Timer gameTimer;
  
  final Random random = Random();
  
  // Background image
  SpriteComponent? background;
  
  @override
  String get gameName => 'Snake Game';
  
  @override
  Color get gameColor => Colors.red.shade400;
  
  @override
  Future<void> onLoad() async {
    await super.onLoad();
    
    // Load background
    try {
      final bgSprite = await Sprite.load('assets/images/snakebg.png');
      background = SpriteComponent(
        sprite: bgSprite,
        size: size,
        position: Vector2.zero(),
      );
      add(background!);
    } catch (e) {
      print('Failed to load background: $e');
    }
    
    resetGame();
  }
  
  @override
  void startGame() {
    if (!isGameStarted) {
      isGameStarted = true;
      direction = Direction.right;
      nextDirection = Direction.right;
      gameTimer = Timer(0.2, repeat: true, onTick: _update);
    }
  }
  
  @override
  void resetGame() {
    // Remove all components except background
    final componentsToRemove = children.where((c) => c != background).toList();
    for (final component in componentsToRemove) {
      remove(component);
    }
    
    score = 0;
    isGameOver = false;
    isGameStarted = false;
    direction = Direction.none;
    nextDirection = Direction.none;
    
    _initializeSnake();
    _spawnFood();
  }
  
  void _initializeSnake() {
    snake = [];
    
    for (int i = 0; i < initialSnakeLength; i++) {
      final position = Vector2(
        (size.x / 2) - (i * gridSize),
        size.y / 2,
      );
      
      final piece = SnakePiece(
        position: position,
        size: Vector2.all(gridSize),
        isHead: i == 0,
      );
      
      snake.add(piece);
      add(piece);
    }
  }
  
  void _spawnFood() {
    // Remove existing food if any
    if (children.any((component) => component is Food)) {
      children.whereType<Food>().forEach(remove);
    }
    
    bool validPosition = false;
    late Vector2 position;
    
    // Find a position that doesn't overlap with the snake or UI
    while (!validPosition) {
      final x = (random.nextInt((size.x ~/ gridSize).floor()) * gridSize);
      final y = (random.nextInt((size.y ~/ gridSize).floor()) * gridSize);
      position = Vector2(x, y);
      
      // Ensure food is not too close to the top (UI area)
      if (y < 50) {
        continue;
      }
      
      // Ensure food is not in the control buttons area (bottom 200 pixels)
      if (y > size.y - 200) {
        continue;
      }
      
      validPosition = true;
      for (final piece in snake) {
        if (piece.position.distanceTo(position) < gridSize) {
          validPosition = false;
          break;
        }
      }
    }
    
    food = Food(
      position: position,
      size: Vector2.all(gridSize),
    );
    
    add(food);
  }
  
  void changeDirection(Direction newDirection) {
    // Prevent 180-degree turns
    if ((direction == Direction.up && newDirection == Direction.down) ||
        (direction == Direction.down && newDirection == Direction.up) ||
        (direction == Direction.left && newDirection == Direction.right) ||
        (direction == Direction.right && newDirection == Direction.left)) {
      return;
    }
    
    nextDirection = newDirection;
  }
  
  @override
  KeyEventResult onKeyEvent(
    KeyEvent event,
    Set<LogicalKeyboardKey> keysPressed,
  ) {
    if (!isGameStarted || isGameOver) {
      return KeyEventResult.ignored;
    }
    
    if (event is KeyDownEvent) {
      if (keysPressed.contains(LogicalKeyboardKey.arrowUp)) {
        changeDirection(Direction.up);
      } else if (keysPressed.contains(LogicalKeyboardKey.arrowDown)) {
        changeDirection(Direction.down);
      } else if (keysPressed.contains(LogicalKeyboardKey.arrowLeft)) {
        changeDirection(Direction.left);
      } else if (keysPressed.contains(LogicalKeyboardKey.arrowRight)) {
        changeDirection(Direction.right);
      }
    }
    
    return KeyEventResult.handled;
  }
  
  void _update() {
    if (!isGameStarted || isGameOver) return;
    
    direction = nextDirection;
    
    // Calculate new head position
    final head = snake.first;
    final Vector2 newHeadPosition = head.position.clone();
    
    switch (direction) {
      case Direction.up:
        newHeadPosition.y -= gridSize;
        break;
      case Direction.down:
        newHeadPosition.y += gridSize;
        break;
      case Direction.left:
        newHeadPosition.x -= gridSize;
        break;
      case Direction.right:
        newHeadPosition.x += gridSize;
        break;
      case Direction.none:
        break;
    }
    
    // Check for collisions with walls
    if (newHeadPosition.x < 0 ||
        newHeadPosition.x >= size.x ||
        newHeadPosition.y < 0 ||
        newHeadPosition.y >= size.y) {
      _gameOver();
      return;
    }
    
    // Check for collisions with self
    for (int i = 1; i < snake.length; i++) {
      if (newHeadPosition.distanceTo(snake[i].position) < gridSize / 2) {
        _gameOver();
        return;
      }
    }
    
    // Check for food collision
    bool ate = false;
    if (newHeadPosition.distanceTo(food.position) < gridSize / 2) {
      ate = true;
      score++;
      _spawnFood();
    }
    
    // Move snake
    final newHead = SnakePiece(
      position: newHeadPosition,
      size: Vector2.all(gridSize),
      isHead: true,
    );
    
    // Update old head to be a body piece
    head.isHead = false;
    
    // Add new head
    snake.insert(0, newHead);
    add(newHead);
    
    // Remove tail if didn't eat
    if (!ate) {
      final tail = snake.removeLast();
      remove(tail);
    }
  }
  
  void _gameOver() {
    isGameOver = true;
    isGameStarted = false;
  }
  
  @override
  void update(double dt) {
    super.update(dt);
    if (isGameStarted && !isGameOver) {
      gameTimer.update(dt);
    }
  }
}
