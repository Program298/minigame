import 'package:flame/components.dart';
import 'package:flutter/material.dart';

class SnakePiece extends PositionComponent {
  bool isHead;
  
  SnakePiece({
    required Vector2 position,
    required Vector2 size,
    this.isHead = false,
  }) : super(position: position, size: size);
  
  @override
  void render(Canvas canvas) {
    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    
    // Draw body/head with different colors
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(4)),
      Paint()..color = isHead ? Colors.green.shade800 : Colors.green,
    );
    
    // Draw eyes if this is the head
    if (isHead) {
      final eyeRadius = size.x * 0.15;
      final eyeOffset = size.x * 0.25;
      
      // Left eye
      canvas.drawCircle(
        Offset(size.x - eyeOffset, size.y * 0.3),
        eyeRadius,
        Paint()..color = Colors.white,
      );
      
      // Right eye
      canvas.drawCircle(
        Offset(size.x - eyeOffset, size.y * 0.7),
        eyeRadius,
        Paint()..color = Colors.white,
      );
      
      // Left pupil
      canvas.drawCircle(
        Offset(size.x - eyeOffset, size.y * 0.3),
        eyeRadius * 0.5,
        Paint()..color = Colors.black,
      );
      
      // Right pupil
      canvas.drawCircle(
        Offset(size.x - eyeOffset, size.y * 0.7),
        eyeRadius * 0.5,
        Paint()..color = Colors.black,
      );
    }
  }
}
