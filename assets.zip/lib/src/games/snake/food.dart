import 'package:flame/components.dart';
import 'package:flutter/material.dart';

class Food extends PositionComponent {
  Sprite? sprite;
  bool isLoaded = false;
  
  Food({
    required Vector2 position,
    required Vector2 size,
  }) : super(position: position, size: size);
  
  @override
  Future<void> onLoad() async {
    try {
      sprite = await Sprite.load('food.png');
      isLoaded = true;
    } catch (e) {
      print('Failed to load food sprite: $e');
    }
  }
  
  @override
  void render(Canvas canvas) {
    if (isLoaded && sprite != null) {
      sprite!.render(
        canvas,
        position: Vector2(size.x / 2, size.y / 2),
        anchor: Anchor.center,
        size: size,
      );
    } else {
      // Fallback rendering if sprite isn't loaded
      canvas.drawCircle(
        Offset(size.x / 2, size.y / 2),
        size.x / 2,
        Paint()..color = Colors.red,
      );
    }
  }
}
