import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import 'package:minigame/src/games/brick_breaker/game/brick_breaker_game.dart';

class Brick extends RectangleComponent with HasGameRef<BrickBreakerGame>, CollisionCallbacks {
  final Color color;
  int hitPoints;
  final Function(Vector2) onDestroyed;
  
  Brick({
    required Vector2 position,
    required Vector2 size,
    required this.color,
    required this.hitPoints,
    required this.onDestroyed,
  }) : super(
    position: position,
    size: size,
    anchor: Anchor.center,
    paint: Paint()..color = color,
    children: [RectangleHitbox()],
  );
  
  void hit() {
    hitPoints--;
    
    if (hitPoints <= 0) {
      // Brick destroyed
      final brickPosition = position.clone();
      removeFromParent();
      gameRef.bricks.remove(this);
      onDestroyed(brickPosition);
    } else {
   // Brick damaged - change color to show damage
    // ใช้ clamp เพื่อให้แน่ใจว่าค่า opacity อยู่ระหว่าง 0.0 ถึง 1.0
    final opacity = (hitPoints / 3).clamp(0.0, 1.0);
    paint.color = color.withOpacity(opacity);
    }
  }
}
