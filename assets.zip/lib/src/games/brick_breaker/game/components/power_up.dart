import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import 'package:minigame/src/games/brick_breaker/game/brick_breaker_game.dart';
import 'package:minigame/src/games/brick_breaker/game/components/paddle.dart';

enum PowerUpType {
  ballMultiplier,
  expandPaddle,
  speedBoost,
  slowMotion,
  extraLife,
}

class PowerUp extends SpriteComponent with HasGameRef<BrickBreakerGame>, CollisionCallbacks {
  final PowerUpType type;
  final Function(PowerUpType) onCollected;
  final double fallSpeed = 150;
  
  PowerUp({
    required Vector2 position,
    required Vector2 size,
    required this.type,
    required this.onCollected,
  }) : super(
    position: position,
    size: size,
    anchor: Anchor.center,
  );
  
  @override
  Future<void> onLoad() async {
    await super.onLoad();
    
    // Load appropriate sprite based on power-up type
    final String spritePath;
    switch (type) {
      case PowerUpType.ballMultiplier:
        spritePath = 'powerup_ball.png';
        break;
      case PowerUpType.expandPaddle:
        spritePath = 'powerup_expand.png';
        break;
      case PowerUpType.speedBoost:
        spritePath = 'powerup_speed.png';
        break;
      case PowerUpType.slowMotion:
        spritePath = 'powerup_slow.png';
        break;
      case PowerUpType.extraLife:
        spritePath = 'powerup_life.png';
        break;
    }
    
    // Fallback to colored rectangle if sprite not available
    try {
      sprite = await gameRef.loadSprite(spritePath);
    } catch (e) {
      final Paint paint;
      switch (type) {
        case PowerUpType.ballMultiplier:
          paint = Paint()..color = Colors.red;
          break;
        case PowerUpType.expandPaddle:
          paint = Paint()..color = Colors.blue;
          break;
        case PowerUpType.speedBoost:
          paint = Paint()..color = Colors.yellow;
          break;
        case PowerUpType.slowMotion:
          paint = Paint()..color = Colors.purple;
          break;
        case PowerUpType.extraLife:
          paint = Paint()..color = Colors.green;
          break;
      }
      
      final RectangleComponent rect = RectangleComponent(
        size: size,
        paint: paint,
      );
      add(rect);
    }
    
    add(CircleHitbox());
  }
  
  @override
  void update(double dt) {
    super.update(dt);
    
    position.y += fallSpeed * dt;
    
    // Remove if it falls off screen
    if (position.y > gameRef.size.y + size.y) {
      removeFromParent();
      gameRef.powerUps.remove(this);
    }
  }
  
  @override
  void onCollision(Set<Vector2> intersectionPoints, PositionComponent other) {
    super.onCollision(intersectionPoints, other);
    
    if (other is Paddle) {
      // Power-up collected
      onCollected(type);
      removeFromParent();
      gameRef.powerUps.remove(this);
    }
  }
}
