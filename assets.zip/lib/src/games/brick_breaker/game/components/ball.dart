import 'dart:math';

import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flame_audio/flame_audio.dart';
import 'package:flutter/material.dart';
import 'package:minigame/src/games/brick_breaker/game/brick_breaker_game.dart';
import 'package:minigame/src/games/brick_breaker/game/components/brick.dart';
import 'package:minigame/src/games/brick_breaker/game/components/paddle.dart';

class Ball extends CircleComponent with HasGameRef<BrickBreakerGame>, CollisionCallbacks {
  Vector2 velocity;
  final Function(Ball) onBallLost;
  bool _collisionEnabled = false;
  
  Ball({
    required Vector2 position,
    required double radius,
    required this.velocity,
    required this.onBallLost,
  }) : super(
    position: position,
    radius: radius,
    paint: Paint()..color = Colors.white,
  );
  
  @override
  Future<void> onLoad() async {
    await super.onLoad();
    
    // Add hitbox after component is loaded to ensure proper initialization
    add(CircleHitbox());
    
    // Enable collisions after a small delay to ensure proper initialization
    Future.delayed(const Duration(milliseconds: 50), () {
      _collisionEnabled = true;
    });
  }
  
  @override
  void update(double dt) {
    super.update(dt);
    
    position += velocity * dt;
    
    // Check screen boundaries
    if (position.x <= radius) {
      // Left wall collision
      position.x = radius;
      velocity.x = -velocity.x;
    } else if (position.x >= gameRef.size.x - radius) {
      // Right wall collision
      position.x = gameRef.size.x - radius;
      velocity.x = -velocity.x;
    }
    
    if (position.y <= radius) {
      // Top wall collision
      position.y = radius;
      velocity.y = -velocity.y;
    } else if (position.y >= gameRef.size.y + radius * 2) {
      // Ball lost
      onBallLost(this);
    }
  }
  
  @override
  void onCollision(Set<Vector2> intersectionPoints, PositionComponent other) {
    if (!_collisionEnabled) return;
    
    super.onCollision(intersectionPoints, other);
    
    if (other is Paddle) {
      // Calculate bounce angle based on where the ball hit the paddle
      final paddleCenter = other.position.x;
      final ballCenter = position.x;
      final relativeIntersection = (paddleCenter - ballCenter) / (other.size.x / 2);
      
      // Bounce angle between -60 and 60 degrees
      final bounceAngle = relativeIntersection * (pi / 3);
      
      // Set new velocity
      final speed = velocity.length;
      velocity.x = -speed * sin(bounceAngle);
      velocity.y = -speed * cos(bounceAngle).abs();
      
      // Ensure the ball moves upward after paddle collision
      if (velocity.y > 0) {
        velocity.y = -velocity.y;
      }
      
      // Move ball slightly above paddle to prevent multiple collisions
      position.y = other.position.y - radius - other.size.y / 2 - 1;
      
      // Play sound
      FlameAudio.play('paddle_hit.mp3');
    } else if (other is Brick) {
      // Get the closest intersection point
      final Vector2 intersection = intersectionPoints.first;
      
      // Calculate collision normal based on which side of the brick was hit
      final Vector2 brickCenter = other.position;
      final Vector2 collisionNormal = (position - brickCenter).normalized();
      
      // Calculate reflection vector
      final Vector2 incidentVector = velocity.normalized();
      final double dot = 2 * (incidentVector.dot(collisionNormal));
      final Vector2 reflectionVector = incidentVector - (collisionNormal * dot);
      
      // Apply reflection
      final double speed = velocity.length;
      velocity = reflectionVector.normalized() * speed;
      
      // Ensure we're moving away from the brick to prevent multiple collisions
      final Vector2 awayFromBrick = position - brickCenter;
      if (velocity.dot(awayFromBrick) < 0) {
        velocity = -velocity;
      }
      
      // Move ball slightly away from brick to prevent sticking
      position += collisionNormal * 1.0;
      
      // Damage the brick
      other.hit();
    }
  }
}
