import 'dart:async';
import 'dart:math';
import 'package:flame/game.dart';
import 'package:flame/components.dart';
import 'package:flame/events.dart';
// import 'package:flame/palette.dart';
import 'package:flame_audio/flame_audio.dart';
import 'package:flutter/material.dart';
import 'package:minigame/src/games/brick_breaker/game/components/ball.dart';
import 'package:minigame/src/games/brick_breaker/game/components/brick.dart';
import 'package:minigame/src/games/brick_breaker/game/components/paddle.dart';
import 'package:minigame/src/games/brick_breaker/game/components/power_up.dart';
import 'package:minigame/src/games/brick_breaker/game/components/score_text.dart';
import 'package:minigame/src/games/brick_breaker/game/components/lives_display.dart';

class BrickBreakerGame extends FlameGame
    with HasCollisionDetection, PanDetector {
  final Function(int) onGameOver;
  

  // Game components
  late Paddle paddle;
  final List<Ball> balls = [];
  final List<Brick> bricks = [];
  final List<PowerUp> powerUps = [];
  late ScoreText scoreText;
  late LivesDisplay livesDisplay;

  // Game state
  bool isGameStarted = false;
  int score = 0;
  int lives = 3;
  final Random random = Random();

  // Power-up timers
  Timer? expandPaddleTimer;
  Timer? slowMotionTimer;

  BrickBreakerGame({required this.onGameOver});

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    // Load audio assets
    await FlameAudio.audioCache.loadAll([
      'brick_hit.mp3',
      'paddle_hit.mp3',
      'power_up.mp3',
      'game_over.mp3',
      'background_music.mp3',
    ]);

    

    // Add background
    try {
      final backgroundSprite = await loadSprite('bg3.png');
      if (backgroundSprite != null) {
        add(SpriteComponent(sprite: backgroundSprite, size: size));
      } else {
        print('Error: Failed to load background sprite.');
      }
    } catch (e) {
      print('Error loading background sprite: $e');
    }

    // Add paddle
    paddle = Paddle(
      position: Vector2(size.x / 2, size.y - 50),
      size: Vector2(100, 20),
    );
    add(paddle);

    // Add score display
    scoreText = ScoreText(position: Vector2(20, 20));
    add(scoreText);

    // Add lives display
    livesDisplay = LivesDisplay(
      position: Vector2(size.x - 20, 20),
      lives: lives,
    );
    add(livesDisplay);

    // Setup initial bricks
    await setupBricks();
  }

  Future<void> setupBricks() async {
    const int rows = 5;
    const int bricksPerRow = 8;
    const double brickWidth = 50;
    const double brickHeight = 25;
    const double padding = 5;

    final colors = [
      Colors.red,
      Colors.orange,
      Colors.yellow,
      Colors.green,
      Colors.blue,
    ];

    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < bricksPerRow; j++) {
        final brick = Brick(
          position: Vector2(
            j * (brickWidth + padding) + brickWidth / 2 + padding,
            i * (brickHeight + padding) + brickHeight / 2 + 100,
          ),
          size: Vector2(brickWidth, brickHeight),
          color: colors[i],
          hitPoints: rows - i,
          onDestroyed: (position) {
            score += (rows - i) * 10;
            scoreText.updateScore(score);
            FlameAudio.play('brick_hit.mp3');

            // Chance to spawn power-up
            if (random.nextDouble() < 0.3) {
              spawnPowerUp(position);
            }

            // Check if all bricks are destroyed
            if (bricks.isEmpty) {
              for (final ball in balls) {
                ball.removeFromParent();
              }
              balls.clear();

              //  // Add a new ball at paddle position
              addBall();

              setupBricks();
            }
          },
        );
        bricks.add(brick);
        add(brick);
      }
    }
  }

  void startGame() {
    if (isGameStarted) return;

    isGameStarted = true;
    score = 0;
    lives = 3;

    // Reset paddle
    paddle.size = Vector2(100, 20);
    paddle.position = Vector2(size.x / 2, size.y - 50);

    // Clear existing balls and add a new one
    for (final ball in balls) {
      ball.removeFromParent();
    }
    balls.clear();
    setupBricks();

    // Add initial ball
    addBall();

    // Update score and lives display
    scoreText.updateScore(score);
    livesDisplay.updateLives(lives);

    // Play background music
    FlameAudio.bgm.play('background_music.mp3');
  }

  void addBall() {
    final ball = Ball(
      position: Vector2(paddle.position.x, paddle.position.y - 20),
      radius: 10,
      velocity: Vector2(random.nextDouble() * 200 - 100, -300),
      onBallLost: handleBallLost,
    );
    balls.add(ball);
    add(ball);
  }

  void handleBallLost(Ball ball) {
    ball.removeFromParent();
    balls.remove(ball);

    if (balls.isEmpty) {
      lives--;
      livesDisplay.updateLives(lives);

      if (lives <= 0) {
        gameOver();
      } else {
        addBall();
      }
    }
  }



  void gameOver() {
    isGameStarted = false;
    FlameAudio.bgm.stop();
    FlameAudio.play('game_over.mp3');

    // Clear power-ups
    for (final powerUp in powerUps) {
      powerUp.removeFromParent();
    }
    powerUps.clear();

    // Cancel timers
    expandPaddleTimer?.stop();
    slowMotionTimer?.stop();

    // Notify game screen
    onGameOver(score);
  }

  void spawnPowerUp(Vector2 position) {
    final powerUpTypes = PowerUpType.values;
    final type = powerUpTypes[random.nextInt(powerUpTypes.length)];

    final powerUp = PowerUp(
      position: position.clone(),
      size: Vector2(30, 30),
      type: type,
      onCollected: (PowerUpType collectedType) {
        FlameAudio.play('power_up.mp3');
        activatePowerUp(collectedType);
      },
    );

    powerUps.add(powerUp);
    add(powerUp);
  }

  void activatePowerUp(PowerUpType type) {
    switch (type) {
      case PowerUpType.ballMultiplier:
        // Add two more balls
        for (int i = 0; i < 2; i++) {
          final ball = Ball(
            position: balls.first.position.clone(),
            radius: 10,
            velocity: Vector2(
              random.nextDouble() * 400 - 200,
              random.nextDouble() * -300 - 100,
            ),
            onBallLost: handleBallLost,
          );
          balls.add(ball);
          add(ball);
        }
        break;

      case PowerUpType.expandPaddle:
        // Expand paddle for 10 seconds
        expandPaddleTimer?.stop();
        paddle.size = Vector2(150, 20);
        expandPaddleTimer = Timer(
          10,
          onTick: () {
            paddle.size = Vector2(100, 20);
          },
        );
        break;

      case PowerUpType.speedBoost:
        // Increase ball speed
        for (final ball in balls) {
          ball.velocity = ball.velocity * 1.5;
        }
        break;

      case PowerUpType.slowMotion:
        // Slow down balls for 5 seconds
        slowMotionTimer?.stop();
        for (final ball in balls) {
          ball.velocity = ball.velocity * 0.5;
        }
        slowMotionTimer = Timer(
          5,
          onTick: () {
            for (final ball in balls) {
              ball.velocity = ball.velocity * 2;
            }
          },
        );
        break;

      case PowerUpType.extraLife:
        // Add an extra life
        lives++;
        livesDisplay.updateLives(lives);
        break;
    }
  }

  @override
  void update(double dt) {
    super.update(dt);

    if (!isGameStarted) return;

    // Update timers
    expandPaddleTimer?.update(dt);
    slowMotionTimer?.update(dt);
  }

  @override
  void onPanUpdate(DragUpdateInfo info) {
    if (!isGameStarted) return;

    paddle.position.x += info.delta.global.x;

    // Keep paddle within screen bounds
    if (paddle.position.x < paddle.size.x / 2) {
      paddle.position.x = paddle.size.x / 2;
    } else if (paddle.position.x > size.x - paddle.size.x / 2) {
      paddle.position.x = size.x - paddle.size.x / 2;
    }
  }
}



