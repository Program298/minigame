import 'package:flutter/material.dart';
import 'package:minigame/models/game.dart';
import 'package:minigame/screens/game_start_screen.dart';
import 'package:minigame/widgets/game_card.dart';
import 'package:google_fonts/google_fonts.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 255, 255, 255),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Colors.blue,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ],
                  ),
                  Text(
                    'Games',
                    style: GoogleFonts.poppins(
                      fontSize: 20,
                      fontWeight: FontWeight.w500,
                      color: const Color.fromARGB(255, 58, 60, 56),
                    ),
                  ),
                  const Icon(Icons.search, color: Color.fromARGB(255, 58, 60, 56)),
                ],
              ),
              const SizedBox(height: 30),
              Expanded(
                child: ListView.builder(
                  itemCount: games.length + 1,
                  itemBuilder: (context, index) {
                    if (index < games.length) {
                      return Padding(
                        padding: const EdgeInsets.only(
                          bottom: 50.0,
                        ), // Increased spacing between cards
                        child: GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder:
                                    (context) =>
                                        GameStartScreen(game: games[index]),
                              ),
                            );
                          },
                          child: GameCard(game: games[index]),
                        ),
                      );
                    } else {
                      // Special offer card
                      // return Container(
                      //   margin: const EdgeInsets.only(bottom: 20),
                      //   height: 100,
                      //   decoration: BoxDecoration(
                      //     color: const Color(0xFF4E7D33).withOpacity(0.2),
                      //     borderRadius: BorderRadius.circular(20),
                      //   ),
                      //   // child: Stack(
                      //   //   clipBehavior: Clip.none, // Allow children to overflow
                      //   //   children: [
                      //   //     Row(
                      //   //       children: [
                      //   //         Container(
                      //   //           width: 100,
                      //   //           decoration: BoxDecoration(
                      //   //             color: const Color(
                      //   //               0xFF4E7D33,
                      //   //             ).withOpacity(0.3),
                      //   //             borderRadius: const BorderRadius.only(
                      //   //               topLeft: Radius.circular(20),
                      //   //               bottomLeft: Radius.circular(20),
                      //   //             ),
                      //   //           ),
                      //   //         ),
                      //   //         Expanded(
                      //   //           child: Padding(
                      //   //             padding: const EdgeInsets.all(12.0),
                      //   //             child: Column(
                      //   //               crossAxisAlignment:
                      //   //                   CrossAxisAlignment.start,
                      //   //               mainAxisAlignment:
                      //   //                   MainAxisAlignment.center,
                      //   //               children: [
                      //   //                 Text(
                      //   //                   'Pack of 3 Games',
                      //   //                   style: GoogleFonts.poppins(
                      //   //                     fontSize: 14,
                      //   //                     fontWeight: FontWeight.w500,
                      //   //                     color: Colors.white,
                      //   //                   ),
                      //   //                 ),
                      //   //                 Text(
                      //   //                   'Multiplayer Games',
                      //   //                   style: GoogleFonts.poppins(
                      //   //                     fontSize: 12,
                      //   //                     color: Colors.white70,
                      //   //                   ),
                      //   //                 ),
                      //   //                 Text(
                      //   //                   'Limited in Stocks',
                      //   //                   style: GoogleFonts.poppins(
                      //   //                     fontSize: 12,
                      //   //                     color: Colors.white70,
                      //   //                   ),
                      //   //                 ),
                      //   //               ],
                      //   //             ),
                      //   //           ),
                      //   //         ),
                      //   //         Container(
                      //   //           padding: const EdgeInsets.all(12),
                      //   //           child: Column(
                      //   //             mainAxisAlignment: MainAxisAlignment.center,
                      //   //             children: [
                      //   //               Text(
                      //   //                 'Buy Now',
                      //   //                 style: GoogleFonts.poppins(
                      //   //                   fontSize: 12,
                      //   //                   color: Colors.white,
                      //   //                 ),
                      //   //               ),
                      //   //               Text(
                      //   //                 '\$14.99',
                      //   //                 style: GoogleFonts.poppins(
                      //   //                   fontSize: 18,
                      //   //                   fontWeight: FontWeight.bold,
                      //   //                   color: Colors.white,
                      //   //                 ),
                      //   //               ),
                      //   //             ],
                      //   //           ),
                      //   //         ),
                      //   //       ],
                      //   //     ),
                      //   //     // Positioned characters with overflow
                      //   //     Positioned(
                      //   //       bottom: -15,
                      //   //       left: -15,
                      //   //       child: Image.asset(
                      //   //         'assets/images/mario.png',
                      //   //         width: 70,
                      //   //         height: 70,
                      //   //       ),
                      //   //     ),
                      //   //     Positioned(
                      //   //       top: -15,
                      //   //       right: 15,
                      //   //       child: Image.asset(
                      //   //         'assets/images/angry_bird.png',
                      //   //         width: 40,
                      //   //         height: 40,
                      //   //       ),
                      //   //     ),
                      //   //   ],
                      //   // ),
                      // );
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
